# Kiosk Script Setup

## File: `kiosk.sh`
## Location: `/home/kiosk/kiosk.sh`

## What It Does

This script is the core of the kiosk. It disables screen blanking and launches Chromium in fullscreen kiosk mode pointed at the target URL. No address bar, no tabs, no browser controls — just the website.

## The Script

```bash
#!/bin/bash

xset s off
xset -dpms
xset s noblank

chromium --kiosk --noerrdialogs --disable-infobars --disable-translate --no-first-run --disable-features=TranslateUI --incognito --disable-pinch --overscroll-history-navigation=0 https://www.raspberrypi.com
```

## What Each Part Does

### Screen Settings
- `xset s off` — disables the screensaver
- `xset -dpms` — disables display power management (screen won't turn off)
- `xset s noblank` — prevents the screen from going blank

### Chromium Flags
- `--kiosk` — fullscreen mode, no address bar, no tabs, no way to navigate away
- `--noerrdialogs` — suppresses error popups like "Chromium didn't shut down correctly"
- `--disable-infobars` — hides info bars at the top of the browser
- `--disable-translate` — prevents "translate this page?" popup
- `--no-first-run` — skips the welcome/setup screen on first launch
- `--disable-features=TranslateUI` — another layer of disabling the translate popup
- `--incognito` — no history, cookies, or cache saved between sessions
- `--disable-pinch` — disables pinch-to-zoom on touchscreen
- `--overscroll-history-navigation=0` — disables swipe-left/right to go back/forward

## Setup Steps

1. Create the script:
   ```
   nano ~/kiosk.sh
   ```
2. Paste the script contents above (change the URL to your target)
3. Make it executable:
   ```
   chmod +x ~/kiosk.sh
   ```
4. Test it:
   ```
   ~/kiosk.sh
   ```
5. Close with Alt+F4 (or Cmd+Q on Mac VM)

## Notes

- Must be run from a user logged into the desktop (not via `su` from another user)
- The `DISPLAY` environment variable must be set (happens automatically when you log in at the login screen)
- On the real Pi, change `chromium` to `chromium-browser` if needed
- Change the URL at the end to your dad's web app URL for production
- If running as root (not recommended), add `--no-sandbox` flag
