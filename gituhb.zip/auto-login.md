# Auto-Login Setup

## File: `autologin.conf`
## Location: `/etc/lightdm/lightdm.conf.d/autologin.conf`

## What It Does

Configures LightDM (the login/display manager) to automatically log in as the kiosk user on boot, skipping the login screen entirely. No username or password prompt — power on and go straight to the desktop.

## The Config File

```
[Seat:*]
autologin-user=kiosk
autologin-user-timeout=0
```

## What Each Part Does

- `[Seat:*]` — applies to all display seats (required section header)
- `autologin-user=kiosk` — auto-login as the "kiosk" user
- `autologin-user-timeout=0` — login immediately with no delay (0 seconds)

## Setup Steps

1. Create the kiosk user (if not already done):
   ```
   adduser kiosk
   ```

2. Add kiosk to the autologin group:
   ```
   groupadd -f autologin
   usermod -a -G autologin kiosk
   ```

3. Create the config directory:
   ```
   mkdir -p /etc/lightdm/lightdm.conf.d/
   ```

4. Create the config file:
   ```
   nano /etc/lightdm/lightdm.conf.d/autologin.conf
   ```

5. Paste the config contents above

6. Save and exit (Ctrl+O, Enter, Ctrl+X)

7. Reboot to test:
   ```
   reboot
   ```

## Keyring Popup Fix

When auto-login is enabled, the GNOME Keyring doesn't get unlocked automatically (since no password was typed). This causes a popup asking to unlock the keyring. To fix:

1. Delete existing keyring files:
   ```
   rm ~/.local/share/keyrings/*
   ```
2. Reboot — when the keyring popup appears, leave both password fields blank and click Continue
3. Confirm "Store passwords unencrypted" — this is fine for a kiosk running in incognito mode

## Troubleshooting

- **Still showing login screen?** Make sure `autologin-user-timeout=0` uses the number zero, not the letter O
- **Still showing login screen?** Check there's no leading space before `autologin-user=kiosk`
- **Still showing login screen?** Make sure the file is in `/etc/lightdm/lightdm.conf.d/` not just `/etc/lightdm/`
- **Still showing login screen?** Verify the kiosk user is in the autologin group: `groups kiosk`

## Notes

- All commands in Setup Steps must be run as root
- This config uses LightDM which is the default on Debian XFCE and Raspberry Pi OS
- On Raspberry Pi OS, you can also use `raspi-config` → System Options → Boot / Auto Login → Desktop Autologin
- The `.conf.d/` directory method takes priority over the main `lightdm.conf` file
