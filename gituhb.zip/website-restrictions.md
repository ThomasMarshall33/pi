# Website Restrictions Setup

## File: `kiosk_policy.json`
## Location: `/etc/chromium/policies/managed/kiosk_policy.json`

## What It Does

This Chromium policy file blocks every website except the ones you explicitly allow. It also disables downloads, developer tools, and the bookmark bar. Chromium reads this file automatically on launch — no browser extensions or extra software needed.

## The Policy File

```json
{
  "URLAllowlist": ["raspberrypi.com", "*.raspberrypi.com", "www.raspberrypi.com"],
  "URLBlocklist": ["*"],
  "BookmarkBarEnabled": false,
  "DownloadRestrictions": 3,
  "DeveloperToolsAvailability": 2
}
```

## What Each Part Does

- `URLBlocklist: ["*"]` — blocks every single website
- `URLAllowlist: [...]` — overrides the blocklist for these specific domains only
- `*.raspberrypi.com` — allows all subdomains (e.g., `docs.raspberrypi.com`)
- `BookmarkBarEnabled: false` — hides the bookmark bar
- `DownloadRestrictions: 3` — blocks all downloads
- `DeveloperToolsAvailability: 2` — completely disables dev tools (F12)

## How the Allow/Block Logic Works

The blocklist runs first and blocks everything. Then the allowlist overrides it for specific domains. So it's a "block all, then allow only what you specify" approach. You only need to list the domains you want to allow — everything else is automatically blocked.

## Setup Steps

1. Switch to root:
   ```
   su - root
   ```
2. Create the directory:
   ```
   mkdir -p /etc/chromium/policies/managed/
   ```
3. Create the policy file:
   ```
   nano /etc/chromium/policies/managed/kiosk_policy.json
   ```
4. Paste the JSON contents above
5. Save and exit (Ctrl+O, Enter, Ctrl+X)
6. Restart Chromium to apply

## For Production

Replace the raspberrypi.com entries with your actual target website:

```json
{
  "URLAllowlist": ["yourdadssite.com", "*.yourdadssite.com", "www.yourdadssite.com"],
  "URLBlocklist": ["*"],
  "BookmarkBarEnabled": false,
  "DownloadRestrictions": 3,
  "DeveloperToolsAvailability": 2
}
```

If the web app loads resources from other domains (like a CDN for images or scripts), you'll need to add those domains to the allowlist too, otherwise parts of the page might not load.

## Notes

- This is a system-wide policy — applies to ALL users, not just kiosk
- No need to create this file per-user
- Must be created as root (the `/etc/` directory requires root access)
- Chromium reads the policy on every launch, no restart of the OS needed
- You can verify policies are loaded by visiting `chrome://policy` in Chromium (if not in kiosk mode)
