# What's Next

## Remaining phases to complete:

### Network Config Portal (Next Up)
- Modify `kiosk.sh` to check for a network connection on boot
- If network exists → open target website as normal
- If no network → open a local config page where user can set up WiFi or Ethernet
- Options: RaspAP (easiest), custom HTML page with nmcli backend, or captive portal approach

### Barcode Scanner Integration
- USB barcode scanners act as keyboard input (HID mode) — mostly plug-and-play
- Scanner "types" the barcode value into whatever text field is focused in the browser
- Web app needs an input field with autofocus to receive the scan
- Test with `lsusb` to verify scanner is detected

### Security Hardening
- Enable overlay filesystem (read-only SD card)
- Disable keyboard shortcuts in kiosk mode
- Remove unnecessary packages
- Disable Bluetooth if not needed
- Physical case with lock to prevent SD card removal
- Set up SSH for remote management

### Testing
- Cold boot test
- Touchscreen test (on real Pi only)
- Barcode scanner input test
- Network failover test (no network → config page)
- Website blocking test
- Power loss recovery test
- 24-hour stability test

### Deployment
- Flash final Pi OS image
- Clone SD card as backup
- Mount Pi + touchscreen at business location
- Document credentials and config for dad
