# Autostart Chromium on Login

## File: `kiosk.desktop`
## Location: `/home/kiosk/.config/autostart/kiosk.desktop`

## What It Does

Tells the XFCE desktop environment to automatically run the kiosk script when the kiosk user logs in. Combined with auto-login, this means: power on → auto-login → kiosk script runs → Chromium opens fullscreen. Zero user interaction needed.

## The Desktop Entry File

```
[Desktop Entry]
Type=Application
Name=Kiosk
Exec=/home/kiosk/kiosk.sh
X-GNOME-Autostart-enabled=true
```

## What Each Part Does

- `[Desktop Entry]` — standard header for .desktop files
- `Type=Application` — tells the system this launches an application
- `Name=Kiosk` — display name (doesn't matter, just for reference)
- `Exec=/home/kiosk/kiosk.sh` — the full path to the kiosk script to run
- `X-GNOME-Autostart-enabled=true` — enables the autostart entry

## Setup Steps

1. Make sure you're logged in as the kiosk user

2. Create the autostart directory:
   ```
   mkdir -p ~/.config/autostart
   ```

3. Create the desktop entry file:
   ```
   nano ~/.config/autostart/kiosk.desktop
   ```

4. Paste the contents above

5. Save and exit (Ctrl+O, Enter, Ctrl+X)

6. Make sure `kiosk.sh` exists and is executable:
   ```
   ls -la ~/kiosk.sh
   ```
   Should show `-rwxr-xr-x` (the x means executable). If not:
   ```
   chmod +x ~/kiosk.sh
   ```

7. Reboot to test

## The Full Boot Sequence

```
Power on
  → GRUB bootloader (auto-selects Debian)
  → LightDM auto-logs in as kiosk user
  → XFCE desktop loads
  → Autostart runs kiosk.sh
  → Screen blanking disabled
  → Chromium launches fullscreen in kiosk mode
  → Target website loads
```

## Notes

- This file must be in the kiosk user's home directory, not root's
- The `Exec=` path must be the full absolute path, not `~/kiosk.sh`
- On Raspberry Pi OS with Wayland/labwc, the autostart method is different — you'd edit `~/.config/labwc/autostart` instead
- On Raspberry Pi OS with LXDE, you'd edit `~/.config/lxsession/LXDE-pi/autostart` instead
- The XFCE method shown here works for the Debian VM practice environment
