# Production Pi Kiosk

A locked-down Raspberry Pi touchscreen kiosk that boots into a restricted fullscreen web browser for use at a business location.

## What It Does

- Powers on and auto-logs into a dedicated kiosk user (no login screen)
- Launches Chromium in fullscreen kiosk mode pointed at a target website
- Blocks all websites except the approved URL
- Accepts USB barcode scanner input (acts as keyboard input to the browser)
- Disables downloads, developer tools, bookmarks, and browser navigation
- Screen never sleeps or blanks

## Project Status

| Phase | Status |
|---|---|
| Research | ✅ Done |
| Kiosk Mode (fullscreen browser) | ✅ Done |
| Website Restrictions (Chromium policy) | ✅ Done |
| Auto-Login on Boot | ✅ Done |
| Autostart Chromium on Login | ✅ Done |
| Network Config Portal | 🔲 Next |
| Barcode Scanner Integration | 🔲 To Do |
| Security Hardening | 🔲 To Do |
| Testing | 🔲 To Do |
| Deployment to Real Pi | 🔲 To Do |

## Files Overview

| File | Location | Purpose |
|---|---|---|
| `kiosk.sh` | `/home/kiosk/kiosk.sh` | Main kiosk launch script |
| `kiosk_policy.json` | `/etc/chromium/policies/managed/kiosk_policy.json` | URL allowlist/blocklist |
| `kiosk.desktop` | `/home/kiosk/.config/autostart/kiosk.desktop` | Autostart on login |
| `autologin.conf` | `/etc/lightdm/lightdm.conf.d/autologin.conf` | Auto-login config |

## Quick Start

See each file's individual README for setup instructions:

- [Kiosk Script Setup](docs/kiosk-script.md)
- [Website Restrictions Setup](docs/website-restrictions.md)
- [Auto-Login Setup](docs/auto-login.md)
- [Autostart Setup](docs/autostart.md)

## Target OS

- **Practice/Dev VM:** Debian 12 (Rosetta ARM64) via UTM on Mac
- **Production:** Raspberry Pi OS with Desktop (Bookworm, 64-bit)

## Hardware (TBD)

- Raspberry Pi 4 or 5
- Official 7" Touch Display 2 (recommended)
- USB barcode scanner (HID/keyboard mode)
- Official Pi power supply
- Case/enclosure
- MicroSD 32GB+
